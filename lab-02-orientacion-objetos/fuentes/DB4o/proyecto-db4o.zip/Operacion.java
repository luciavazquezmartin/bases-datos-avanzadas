import java.util.Date;

public abstract class Operacion {
    protected int codigo;
    protected String concepto;
    protected Date fecha;
    protected double cantidad;
    protected Cuenta cuentaOrigen;

    public Operacion(int codigo, String concepto, Date fecha, double cantidad, Cuenta origen) {
        if (codigo <= 0 || codigo > 99999999) throw new IllegalArgumentException("El codigo la operacion debe ser positivo y debe tener como maximo 8 digitos");

        if (concepto != null && concepto.length() > 250) throw new IllegalArgumentException("El concepto de la operacion no debe superar los 250 caracteres");

        if (fecha == null) throw new IllegalArgumentException("La fecha de la operacion no puede ser nula");

        if (cantidad <= 0) throw new IllegalArgumentException("La cantidad a gestionar en la operacion debe ser positiva");

        if (origen == null) throw new IllegalArgumentException("La cuenta de origen en la operacion no puede ser nula");
        
        if (fecha.before(origen.getFechaCreacion())) {
            throw new IllegalArgumentException("La fecha en la operacion no puede ser anterior a la creacion de la cuenta de origen");
        }

        this.codigo = codigo;
        this.concepto = concepto;
        this.fecha = fecha;
        this.cantidad = cantidad;
        this.cuentaOrigen = origen;
    }

    public int getCodigo() { return codigo; }
}