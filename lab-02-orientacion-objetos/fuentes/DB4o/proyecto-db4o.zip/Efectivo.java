import java.util.Date;

public class Efectivo extends Operacion {
    private Oficina oficina;

    public Efectivo(int codigo, String concepto, Date fecha, double cantidad, Cuenta origen, Oficina oficina) {
        super(codigo, concepto, fecha, cantidad, origen);
        if (oficina == null) throw new IllegalArgumentException("La oficina asociada a las operaciones en efectivo no puede ser nula");
        this.oficina = oficina;
    }

    public Oficina getOficina() {
        return this.oficina;
    }
}