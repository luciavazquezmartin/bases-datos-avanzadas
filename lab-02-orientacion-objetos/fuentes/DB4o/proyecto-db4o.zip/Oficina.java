public class Oficina {
    private int codigo;
    private long telefono;
    private String direccion;

    public Oficina(int codigo, long telefono, String direccion) {
        // 1. Validación de Código
        if (codigo <= 0 || codigo > 99999) {
            throw new IllegalArgumentException("El codigo de la oficina debe ser positivo y debe tener como maximo 5 digitos");
        }

        // 2. Validación de Teléfono
        if (telefono < 100000000 || telefono > 999999999) {
            throw new IllegalArgumentException("El telefono del cliente debe tener 9 digitos");
        }

        // 3. Validación de Dirección
        if (direccion == null || direccion.trim().isEmpty()) {
            throw new IllegalArgumentException("La direccion de la oficina no puede ser nula");
        }
        if (direccion.length() > 100) {
            throw new IllegalArgumentException("La direccion de la oficina no debe superar los 100 caracteres");
        }

        this.codigo = codigo;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public int getCodigo() { return codigo; }
    public long getTelefono() { return telefono; }
    public String getDireccion() { return direccion; }
}