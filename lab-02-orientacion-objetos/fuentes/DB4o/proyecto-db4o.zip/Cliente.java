import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private String dni;
    private String nombre;
    private String apellidos;
    private String email;
    private int edad;
    private String direccion;
    private long telefono;
    private List<Cuenta> cuentas;

    public Cliente(String dni, String nombre, String apellidos, String email, int edad, String direccion, long telefono) {
        // Validaciones de obligatoriedad y formato
        if (dni == null || !dni.matches("^[0-9]{8}[a-zA-Z]$")) throw new IllegalArgumentException("El DNI no es valido, debe estar formado por 8 numeros y una letra");

        if (nombre == null || nombre.length() > 50) throw new IllegalArgumentException("El nombre del cliente no puede ser nulo y no debe superar los 50 caracteres");

        if (apellidos == null || apellidos.length() > 50) throw new IllegalArgumentException("Los apellidos del cliente no pueden ser nulos y no deben superar los 100 caracteres");

        if (email == null || email.length() > 50 || !email.matches(".+@.+\\..+")) throw new IllegalArgumentException("El formato del email debe ser usuario@dominio.com y no debe superar los 50 caracteres");

        if (direccion == null || direccion.length() > 100) throw new IllegalArgumentException("La direccion del cliente no puede ser nula y no debe superar los 100 caracteres");

        if (telefono < 100000000 || telefono > 999999999) throw new IllegalArgumentException("El telefono del cliente debe tener 9 digitos");

        if (edad < 18 || edad > 999) throw new IllegalArgumentException("La edad minima del cliente debe ser 18 y debe tener como maximo 3 digitos");

        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.edad = edad;
        this.direccion = direccion;
        this.telefono = telefono;
        this.cuentas = new ArrayList<>();
    }

    public void addCuenta(Cuenta c) { this.cuentas.add(c); }
    public String getNombreCompleto() { return nombre + " " + apellidos; }
    public String getDni() { return dni; } 
}