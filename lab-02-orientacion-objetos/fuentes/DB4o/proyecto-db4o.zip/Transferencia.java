import java.util.Date;

public class Transferencia extends Operacion {
    private Cuenta cuentaDestino;

    public Transferencia(int codigo, String concepto, Date fecha, double cantidad, Cuenta origen, Cuenta destino) {
        super(codigo, concepto, fecha, cantidad, origen);
        
        if (destino == null) throw new IllegalArgumentException("La cuenta de destino en una transferencia no puede ser nula");
        
        if (origen.getIban().equals(destino.getIban())) {
            throw new IllegalArgumentException("No se puede transferir dinero a la misma cuenta");
        }

        if (fecha.before(destino.getFechaCreacion())) {
            throw new IllegalArgumentException("La fecha en una transferencia no puede ser anterior a la creacion de la cuenta de destino");
        }

        this.cuentaDestino = destino;
    }
}