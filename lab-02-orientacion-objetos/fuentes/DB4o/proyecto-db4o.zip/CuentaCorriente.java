import java.util.Date;

public class CuentaCorriente extends Cuenta {
    private Oficina oficina;

    public CuentaCorriente(String iban, long numero, Date fecha, double saldo, Oficina oficina) {
        super(iban, numero, fecha, saldo);
        if (oficina == null) throw new IllegalArgumentException("La oficina asociada a la cuenta corriente no puede ser nula");
        this.oficina = oficina;
    }
}