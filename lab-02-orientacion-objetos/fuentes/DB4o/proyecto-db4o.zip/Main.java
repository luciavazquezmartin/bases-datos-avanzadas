import com.db4o.*;
import java.util.Date;
import java.util.Calendar;

public class Main {
    public static void main(String[] args) {
        ObjectContainer db = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(), "banco.db4o");

        try {
            // --- 0. RESETEANDO BASE DE DATOS ---
            System.out.println("--- 0. RESETEANDO BASE DE DATOS ---");
            ObjectSet<Object> registros = db.query(Object.class);
            while(registros.hasNext()) db.delete(registros.next());
            db.commit();

            // --- 1. CREANDO DATOS ---
            System.out.println("\n--- 1. CREANDO DATOS ---");
            Oficina ofi1 = new Oficina(1, 976111222, "Paseo Independencia");
            Cliente ana = new Cliente("12345678A", "Ana", "García", "ana@email.com", 25, "Calle Mayor", 600111222);
            Cliente luis = new Cliente("87654321B", "Luis", "Pérez", "luis@email.com", 40, "Calle Menor", 600333444);
            
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, -10);
            Date fechaAntigua = cal.getTime();
            
            CuentaCorriente c1 = new CuentaCorriente("ES910011", 1111, fechaAntigua, 1000.0, ofi1);
            
            ana.addCuenta(c1); c1.addCliente(ana);
            db.store(ana);
            db.store(luis);
            db.store(ofi1);
            db.store(c1);
            db.commit();
            System.out.println("OK: Datos base insertados.");

            // --- 2. BUSCANDO CLIENTE POR DNI ---
            System.out.println("\n--- 2. BUSCANDO CLIENTE POR DNI (12345678A) ---");
            ObjectSet<Cliente> res = db.query(Cliente.class);
            for (Cliente c : res) {
                if (c.getDni().equals("12345678A")) {
                    System.out.println("¡Encontrada!: " + c.getNombreCompleto());
                }
            }

            // --- 3. ACTUALIZANDO SALDO ---
            System.out.println("\n--- 3. ACTUALIZANDO SALDO DE CUENTA CORRIENTE ---");
            ObjectSet<CuentaCorriente> cuentas = db.query(CuentaCorriente.class);
            if (cuentas.hasNext()) {
                CuentaCorriente cc = cuentas.next();
                System.out.println("Saldo anterior: " + cc.getSaldo());
                cc.setSaldo(cc.getSaldo() + 500.0);
                db.store(cc);
                db.commit();
                System.out.println("Saldo nuevo: " + cc.getSaldo());
            }

            // --- 4. BORRANDO A LUIS PÉREZ ---
            System.out.println("\n--- 4. BORRANDO A LUIS PÉREZ ---");
            ObjectSet<Cliente> clientesABorrar = db.query(Cliente.class);
            while(clientesABorrar.hasNext()) {
                Cliente c = clientesABorrar.next();
                if (c.getNombreCompleto().contains("Luis")) {
                    db.delete(c);
                    System.out.println("Luis eliminado correctamente.");
                }
            }
            db.commit();

            // --- 5. ESTADO FINAL ---
            System.out.println("\n--- 5. ESTADO FINAL ---");
            ObjectSet<Cliente> finales = db.query(Cliente.class);
            System.out.println("Clientes en BD: " + finales.size());
            for (Cliente c : finales) {
                System.out.println("- " + c.getNombreCompleto());
            }

            // --- 6. PROBANDO INTEGRIDAD REFERENCIAL ---
            System.out.println("\n--- 6. PROBANDO INTEGRIDAD: Borrar Oficina de un Efectivo ---");
            Oficina ofiTemporal = new Oficina(99, 900000000, "Calle de Prueba");
            Efectivo ingresoTest = new Efectivo(500, "Ingreso Extra", new Date(), 100.0, c1, ofiTemporal);
            
            db.store(ofiTemporal);
            db.store(ingresoTest);
            db.commit();
            System.out.println("Paso A: Oficina y Efectivo guardados.");

            db.delete(ofiTemporal);
            db.commit();
            System.out.println("Paso B: Oficina borrada de la BD.");

            ObjectSet<Efectivo> todosLosEfectivos = db.query(Efectivo.class);
            while(todosLosEfectivos.hasNext()) {
                Efectivo e = todosLosEfectivos.next();
                if (e.getCodigo() == 500) {
                    if (e.getOficina() == null) {
                        System.out.println("RESULTADO: La referencia es NULL. DB4O ha roto el vínculo.");
                    } else {
                        System.out.println("RESULTADO: El objeto aún tiene la referencia (Sigue en memoria RAM).");
                    }
                }
            }

            // --- 7. PRUEBAS DE ESTRÉS (RESTRICCIONES SQL MAPEADAS A JAVA) ---
            System.out.println("\n--- 7. PRUEBAS DE RESTRICCIONES (LOGS DE ERROR) ---");

            // A. Longitud VARCHAR y Formato DNI
            try {
                System.out.print("Probando DNI mal formado... ");
                new Cliente("123", "Error", "Dni", "e@e.com", 20, "Dir", 600111222);
            } catch (Exception e) { System.out.println("CAPTURADO: " + e.getMessage()); }

            // B. Edad Mínima (CHECK Edad >= 18)
            try {
                System.out.print("Probando Edad < 18... ");
                new Cliente("99999999Z", "Niño", "Perez", "n@p.com", 15, "Dir", 600111222);
            } catch (Exception e) { System.out.println("CAPTURADO: " + e.getMessage()); }

            // C. Saldo Positivo (CHECK Saldo >= 0)
            try {
                System.out.print("Probando Saldo negativo... ");
                new CuentaAhorro("ES8822", 22, new Date(), -500.0, 2.0);
            } catch (Exception e) { System.out.println("CAPTURADO: " + e.getMessage()); }

            // D. Transferencia a sí mismo
            try {
                System.out.print("Probando Transferencia a la misma cuenta... ");
                new Transferencia(10, "Auto-envío", new Date(), 100.0, c1, c1);
            } catch (Exception e) { System.out.println("CAPTURADO: " + e.getMessage()); }

            // E. Lógica de Fechas (Operación antes que Cuenta)
            try {
                System.out.print("Probando Operación en fecha anterior a la cuenta... ");
                cal.add(Calendar.DAY_OF_MONTH, -30); 
                new Efectivo(20, "Viaje al pasado", cal.getTime(), 50.0, c1, ofi1);
            } catch (Exception e) { System.out.println("CAPTURADO: " + e.getMessage()); }

            // F. Oficina: Atributos obligatorios y longitud
            try {
                System.out.print("Probando Oficina con dirección vacía... ");
                new Oficina(5, 976111222, "");
            } catch (Exception e) { System.out.println("CAPTURADO: " + e.getMessage()); }

        } finally {
            db.close();
            System.out.println("\nProceso finalizado.");
        }
    }
}