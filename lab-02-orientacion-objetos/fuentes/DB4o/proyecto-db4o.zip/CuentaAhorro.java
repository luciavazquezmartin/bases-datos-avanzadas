import java.util.Date;

public class CuentaAhorro extends Cuenta {
    private double tipoInteres;

    public CuentaAhorro(String iban, long numero, Date fecha, double saldo, double tipoInteres) {
        super(iban, numero, fecha, saldo);
        if (tipoInteres <= 0) throw new IllegalArgumentException("El tipo de interes de la cuenta de ahorro debe ser positivo");
        this.tipoInteres = tipoInteres;
    }
}