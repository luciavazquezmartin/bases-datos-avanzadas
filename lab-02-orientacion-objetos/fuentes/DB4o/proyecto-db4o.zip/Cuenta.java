import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class Cuenta {
    protected String iban;
    protected long numero;
    protected Date fechaCreacion;
    protected double saldoActual;
    protected List<Cliente> clientes;

    public Cuenta(String iban, long numero, Date fechaCreacion, double saldoActual) {
        if (iban == null || iban.length() > 24) throw new IllegalArgumentException("El IBAN de la cuenta no puede ser nulo y no debe superar los 24 caracteres");
        if (numero <= 0) throw new IllegalArgumentException("El numero de la cuenta no puede ser nulo");
        if (fechaCreacion == null) throw new IllegalArgumentException("La fecha de creacion de la cuenta no puede ser nula");
        if (saldoActual < 0) throw new IllegalArgumentException("El saldo de la cuenta no puede ser negativo");

        this.iban = iban;
        this.numero = numero;
        this.fechaCreacion = fechaCreacion;
        this.saldoActual = saldoActual;
        this.clientes = new ArrayList<>();
    }
    
    public void addCliente(Cliente c) { this.clientes.add(c); }
    public String getIban() { return iban; }
    public double getSaldo() { return saldoActual; }
    public void setSaldo(double saldo) { this.saldoActual = saldo; }
    public Date getFechaCreacion() { return fechaCreacion; }
}